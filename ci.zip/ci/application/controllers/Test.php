<?php

class Test extends CI_Controller{

	public function index(){
		
    $this->load->database();
	echo "This is index function.";
	}
	
	public function ex1(){
	echo "Welcome to code igniter.";
	}
}
?>