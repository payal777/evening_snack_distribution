<html>
	<head>
		<title>Resume</title>
		<style>
table, th, td {
    border: 1px solid black;
	padding: 10px;
    text-align: center;
}
			    .img-circle {
        border-radius: 50%;
    }
</style>
	</head>
	<body style="width:60%;margin-left:auto;
          margin-right:auto;" >
		<div style=" border: 1px solid black ;
             -webkit-box-shadow: 0 10px 6px -6px #777;
             -moz-box-shadow: 0 10px 6px -6px #777;
             box-shadow: 0 10px 6px -6px #777;
             padding:2%;margin: 1%;">
								<div style="display : block;
    margin : auto;text-align: center;"><img class="img-circle" src="http://localhost/ci/application/views/images/flower4.jpg"></div>
		<div>
		<div>
			<div style="width:50%;height:20%;float:left;background: #948F8E;">
				<p>PAYAL ANAND MULIK</p>
			</div>
			<div style="width:50%;height:20%; float:right;background: #F9B4A4;">
				<p>Vidyanagar,Hubli</p>
				<p>9876789876</p>
				<p>payalmulik707@gmail.com<p>
			</div>
		</div>			
			<b>OBJECTIVE</b>
			<p>To have a object oriented and successfull career where I can utilize my skills for the growth of the company.</p>
		</div>
		 <div style="padding:5px;display:table;">
    <table style="margin:5px;">
        <tr>
            <th>Education</th>
            <th>College</th>
            <th>University</th>
			<th>Percentage</th>
        </tr>
		        <tr>
            <td>
                SSC
            </td>
            <td>
                New Public Inter College
            </td>
            <td>
                UP Board
            </td>
					<td>
						72%
					</td>
        </tr>
		        <tr>
            <td>HSSC</td>
            <td>Shiroda Higher Secondary</td>
            <td>Goa Board</td>
					<td>65%</td>
        </tr>
		        <tr>
            <td>BE(CSE)</td>
            <td>Hirasugar Institute Of Technology</td>
            <td>VTU</td>
					<td>65%</td>
        </tr>
				        <tr>
            <td>MTech(CSE)</td>
            <td>VTU</td>
            <td>VTU</td>
							<td>67.5%</td>
        </tr>
    </table>
		</div>
		<div>
			<p><b>SKILLS</b></p>
			<p>C,C++,Core Java,PHP,MySQL</p>
		</div>
		<div>
			<p><b>EXPERIENCE</b></p>
			<p>Four month experience in technology PHP,MySQL,Jquery,HTML,CSS</p>
			</div>
		<div>
			<p><b>PROJECT</b></p>
			<p>A Secure Client Side Deduplication using Cloud Computing.</p>
			<p>Decentralized Low Communication Traffic Alert System Using Cloud Computing.</p>
		</div>
		<div>
			<p><b>HOBBIES</b></p>
			<p>Playing Badminton,Internet Browsing</p>
		</div>
		</div>
	</body>
</html>