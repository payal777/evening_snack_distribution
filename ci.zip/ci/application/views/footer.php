<html>
	<body>
		<div>

<div id="footer">  
        <p>Copyright (c) 2017 All Rights Reserved</p>  
    </div>  
  
</div>  
</body>  
</html>  