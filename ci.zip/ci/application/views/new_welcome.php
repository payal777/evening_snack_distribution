<html>
	<head>
		<title>First CodeIgniter</title>
	</head>
	<body>
		<p>Come to know about controller</p>
		<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
	</body>
</html>