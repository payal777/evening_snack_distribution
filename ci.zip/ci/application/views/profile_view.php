<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>My Profile | Evening Snacks</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home">EVENING SNACKS</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if ($this->session->userdata('login')){ ?>
				<li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
				<li><a href="<?php echo base_url(); ?>index.php/home/logout">Log Out</a></li>
				<?php } else { ?>
				<li><a href="<?php echo base_url(); ?>index.php/login">Login</a></li>
				<li><a href="<?php echo base_url(); ?>index.php/signup">Signup</a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>
<div class="container">
	<div class="row">
		<div class="col-md-4">
			<h4>Profile Summary</h4>
			<hr/>
			<p>Name: <?php echo $uname; ?></p>
			<p>Email: <?php echo $uemail; ?></p>
			<p>...</p>
		</div>
		<div class="col-md-8">
			<p>Click on thumbs Up</p>
			<p>If you want to order evening snacks</p>
			<p>Have a great day!!!!!!!</p>
			<p>...</p>
		</div>
	</div>
    <!-- <script type="text/javascript">
    var clicks = 0;
		var unclicks= clicks;
    function onClick() {
        clicks += 1;
        document.getElementById("clicks").innerHTML = clicks;
    };
		function onUnclick() {
				unclicks = clicks-1;
				document.getElementById("unclicks").innerHTML = unclicks;
		};
    </script>
		<button type="button" class="btn btn-default btn-sm" onClick="onClick()">
	<span class="glyphicon glyphicon-thumbs-up"></span> Like
</button>
    <p>Clicks: <a id="clicks">0</a></p>
		<button type="button" class="btn btn-default btn-sm" onClick="onUnclick()">
	<span class="glyphicon glyphicon-thumbs-down"></span> Unlike
</button>
		<p>UnClicks: <a id="unclicks"></a></p> -->



		<script type="text/javascript">

    function insert_like()
    {
	  $.ajax({
	    type: 'post',
			url:"<?php echo base_url(); ?>" + "index.php/Store_rating",
	    data: {
	      post_like:"like"
	    },
	    success: function (response) {
 	      $('#totalvotes').slideDown()
	      {
	        $('#totalvotes').html(response);
	      }
	    }
	    });
    }

    function insert_dislike()
    {
	  $.ajax({
	    type: 'post',
	    url: "<?php echo base_url(); ?>" + "index.php/Store_rating",
	    data: {
	      post_dislike:"dislike"
	    },
	    success: function (response) {
 	      $('#totalvotes').slideDown()
	      {
	        $('#totalvotes').html(response);
	      }
	    }
	    });
    }
</script>





	<button type="button" class="glyphicon glyphicon-thumbs-up" onclick="insert_like();" id="like_button">
  <button type="button" class="glyphicon glyphicon-thumbs-down" onclick="insert_dislike();" id="dislike_button">
  <div id="totalvotes"></div>
</div>
<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
</body>
</html>
